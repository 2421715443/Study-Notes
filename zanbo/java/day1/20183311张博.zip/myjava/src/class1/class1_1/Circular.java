package class1.class1_1;

import java.util.Scanner;

public class Circular {
	public static void main(String[] args) {
		Scanner rect = new Scanner(System.in);
		System.out.println("����Բ�εİ뾶");
		float ban = rect.nextFloat();
		System.out.println("Բ�ε��ܳ�Ϊ" + (ban * 2 * 3.14169));
		System.out.println("Բ�ε����Ϊ" + (ban * ban * 3.14169));
	}
}
